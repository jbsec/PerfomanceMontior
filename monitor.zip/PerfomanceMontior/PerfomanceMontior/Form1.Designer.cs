﻿namespace PerfomanceMontior
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.CPUCIR = new CircularProgressBar.CircularProgressBar();
            this.RAMCIR = new CircularProgressBar.CircularProgressBar();
            this.CPU1 = new System.Diagnostics.PerformanceCounter();
            this.RAM = new System.Diagnostics.PerformanceCounter();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CPU1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RAM)).BeginInit();
            this.SuspendLayout();
            // 
            // CPUCIR
            // 
            this.CPUCIR.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.CPUCIR.AnimationSpeed = 500;
            this.CPUCIR.BackColor = System.Drawing.Color.Transparent;
            this.CPUCIR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.CPUCIR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.CPUCIR.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CPUCIR.InnerMargin = 2;
            this.CPUCIR.InnerWidth = -1;
            this.CPUCIR.Location = new System.Drawing.Point(120, 89);
            this.CPUCIR.MarqueeAnimationSpeed = 2000;
            this.CPUCIR.Name = "CPUCIR";
            this.CPUCIR.OuterColor = System.Drawing.Color.Gray;
            this.CPUCIR.OuterMargin = -25;
            this.CPUCIR.OuterWidth = 26;
            this.CPUCIR.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.CPUCIR.ProgressWidth = 25;
            this.CPUCIR.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.CPUCIR.Size = new System.Drawing.Size(276, 259);
            this.CPUCIR.StartAngle = 270;
            this.CPUCIR.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.CPUCIR.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.CPUCIR.SubscriptText = ".23";
            this.CPUCIR.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.CPUCIR.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.CPUCIR.SuperscriptText = "°C";
            this.CPUCIR.TabIndex = 0;
            this.CPUCIR.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.CPUCIR.Value = 68;
            // 
            // RAMCIR
            // 
            this.RAMCIR.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.Liner;
            this.RAMCIR.AnimationSpeed = 500;
            this.RAMCIR.BackColor = System.Drawing.Color.Transparent;
            this.RAMCIR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.RAMCIR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.RAMCIR.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.RAMCIR.InnerMargin = 2;
            this.RAMCIR.InnerWidth = -1;
            this.RAMCIR.Location = new System.Drawing.Point(529, 89);
            this.RAMCIR.MarqueeAnimationSpeed = 2000;
            this.RAMCIR.Name = "RAMCIR";
            this.RAMCIR.OuterColor = System.Drawing.Color.Gray;
            this.RAMCIR.OuterMargin = -25;
            this.RAMCIR.OuterWidth = 26;
            this.RAMCIR.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.RAMCIR.ProgressWidth = 25;
            this.RAMCIR.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.RAMCIR.Size = new System.Drawing.Size(276, 259);
            this.RAMCIR.StartAngle = 270;
            this.RAMCIR.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.RAMCIR.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.RAMCIR.SubscriptText = ".23";
            this.RAMCIR.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.RAMCIR.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.RAMCIR.SuperscriptText = "°C";
            this.RAMCIR.TabIndex = 1;
            this.RAMCIR.TextMargin = new System.Windows.Forms.Padding(8, 8, 0, 0);
            this.RAMCIR.Value = 68;
            // 
            // CPU1
            // 
            this.CPU1.CategoryName = "Processor";
            this.CPU1.CounterName = "% Processor Time";
            this.CPU1.InstanceName = "_Total";
            // 
            // RAM
            // 
            this.RAM.CategoryName = "Memory";
            this.RAM.CounterName = "% Committed Bytes In Use";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(206, 382);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 44);
            this.label1.TabIndex = 2;
            this.label1.Text = "CPU";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(627, 382);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 44);
            this.label2.TabIndex = 3;
            this.label2.Text = "RAM";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(902, 518);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.RAMCIR);
            this.Controls.Add(this.CPUCIR);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CPU1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RAM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private CircularProgressBar.CircularProgressBar CPUCIR;
        private CircularProgressBar.CircularProgressBar RAMCIR;
        private System.Diagnostics.PerformanceCounter CPU1;
        private System.Diagnostics.PerformanceCounter RAM;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

