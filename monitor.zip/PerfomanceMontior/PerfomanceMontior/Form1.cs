﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PerfomanceMontior
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // This was created by accident. I'm going to keep it here anyway because if I delete it; the program will
            // stop working. Don't delete this form1load object. Just keep it here.
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            float fcpu = CPU1.NextValue();
            float dram = RAM.NextValue();
            CPUCIR.Value = (int)fcpu;
            CPUCIR.Text = string.Format("{0:0.00}%", fcpu);

            CPUCIR.Value = (int)dram;
            CPUCIR.Text = string.Format("{0:0.00}%", dram);
        }
    }
}
